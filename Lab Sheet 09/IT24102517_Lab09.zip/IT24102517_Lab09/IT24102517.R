setwd("C:\\Users\\Nethmi Balasooriya\\Desktop\\IT24102517_Lab09")

# Question 1
# i.
set.seed(123)   
baking_time <- rnorm(25, mean = 45, sd = 2)
print(baking_time)


# ii.
t_test_result <- t.test(baking_time, mu = 46, alternative = "less")
print(t_test_result)